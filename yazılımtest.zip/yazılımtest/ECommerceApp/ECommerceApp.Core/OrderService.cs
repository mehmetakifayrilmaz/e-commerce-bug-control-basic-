﻿using System;

namespace ECommerceApp.Core
{
    public class OrderService
    {
        public bool PlaceOrder(Cart cart)
        {
            if (cart.Items.Count == 0)
                return false;

            

            
            

            return true;
        }
    }
}