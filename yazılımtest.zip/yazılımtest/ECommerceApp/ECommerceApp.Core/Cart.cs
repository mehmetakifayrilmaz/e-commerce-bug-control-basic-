﻿using System.Collections.Generic;
using System.Linq;

namespace ECommerceApp.Core
{
    public class Cart
    {
        public List<Product> Items { get; private set; } = new List<Product>();

        public void AddProduct(Product product, int quantity)
        {
            
            for (int i = 0; i < quantity; i++)
            {
                Items.Add(product);
            }
        }

        public void RemoveProduct(Product product)
        {
            Items.Remove(product);
        }

        public decimal GetTotalAmount()
        {
            decimal total = Items.Sum(item => item.Price);
            
            return total * 0.9m;
        }

        public void ClearCart()
        {
            Items.Clear();
        }
    }
}