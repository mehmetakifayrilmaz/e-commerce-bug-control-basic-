﻿using NUnit.Framework;
using ECommerceApp.Core;
using System;
using System.Linq;

namespace ECommerceApp.Tests
{
    [TestFixture]
    public class ECommerceTests
    {
        private Cart _cart;
        private Product _product1;
        private Product _product2;
        private OrderService _orderService;

        [SetUp]
        public void Setup()
        {
            _cart = new Cart();
            _orderService = new OrderService();
            // Testlerde kullanacağımız örnek ürünler
            _product1 = new Product(1, "Laptop", 20000m, 5);
            _product2 = new Product(2, "Mouse", 500m, 100);
        }

        // ==========================================
        // 1. UNIT TEST (WHITE BOX TESTS)
        // ==========================================

        [Test]
        public void WhiteBox_AddProduct_ShouldIncreaseItemCount()
        {
            _cart.AddProduct(_product1, 1);
            Assert.That(_cart.Items.Count, Is.EqualTo(1));
        }

        [Test]
        public void WhiteBox_ProductPrice_ShouldNotBeNegative()
        {
            var invalidProduct = new Product(3, "Hatalı Ürün", -100m, 10);
            Assert.That(invalidProduct.Price, Is.GreaterThanOrEqualTo(0), "Ürün fiyatı negatif olamaz!");
        }

        [Test]
        public void WhiteBox_AddProduct_WithNegativeQuantity_ShouldThrowException()
        {
            Assert.Throws<ArgumentException>(() => _cart.AddProduct(_product1, -2), "Negatif ürün adedi eklenememeli!");
        }

        // ==========================================
        // 2. BLACK BOX TESTS
        // ==========================================

        [Test]
        public void BlackBox_CartTotal_ShouldBeCalculatedCorrectly()
        {
            _cart.AddProduct(_product1, 1); 
            _cart.AddProduct(_product2, 2); 
            Assert.That(_cart.GetTotalAmount(), Is.EqualTo(21000m), "Sepet toplamı yanlış hesaplanıyor!");
        }

        [Test]
        public void BlackBox_RemoveProduct_ShouldDecreaseTotal()
        {
            _cart.AddProduct(_product1, 1);
            _cart.AddProduct(_product2, 1);
            _cart.RemoveProduct(_product2);
            Assert.That(_cart.GetTotalAmount(), Is.EqualTo(20000m));
        }

        [Test]
        public void BlackBox_EmptyCart_ShouldReturnZeroTotal()
        {
            Assert.That(_cart.GetTotalAmount(), Is.EqualTo(0m));
        }

        // ==========================================
        // 3. GRAY BOX TESTS
        // ==========================================

        [Test]
        public void GrayBox_CartState_ShouldRemainConsistentAfterMultipleOperations()
        {
            _cart.AddProduct(_product1, 3);
            _cart.RemoveProduct(_product1);

            int remainingLaptops = _cart.Items.Count(p => p.Id == 1);
            Assert.That(remainingLaptops, Is.EqualTo(2));
        }

        [Test]
        public void GrayBox_CartClear_ShouldRemoveAllReferences()
        {
            _cart.AddProduct(_product1, 1);
            _cart.ClearCart();
            Assert.That(_cart.Items.Count, Is.EqualTo(0));
            Assert.That(_cart.GetTotalAmount(), Is.EqualTo(0m));
        }

        // ==========================================
        // 4. INTEGRATION TESTS
        // ==========================================

        [Test]
        public void Integration_PlaceOrder_WithInsufficientStock_ShouldFail()
        {
            _cart.AddProduct(_product1, 10); 
            bool orderResult = _orderService.PlaceOrder(_cart);

            Assert.That(orderResult, Is.False, "Stokta yeterli ürün yokken sipariş onaylanmamalı!");
        }

        [Test]
        public void Integration_PlaceOrder_ShouldClearCartAfterSuccess()
        {
            _cart.AddProduct(_product2, 1);
            bool orderResult = _orderService.PlaceOrder(_cart);

            Assert.That(orderResult, Is.True);
            Assert.That(_cart.Items.Count, Is.EqualTo(0), "Sipariş verildikten sonra sepet temizlenmeli!");
        }
    }
}